# SKILLED VIHARI FARMSTAY

Static Netlify site. Entry point: `index.html`.

## Netlify
No build command is required. Publish directory is the repository root.
